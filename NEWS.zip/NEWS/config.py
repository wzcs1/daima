from redis import StrictRedis
import logging
#创建配置类
class Config(object):
    DEBUG = True
    SQLALCHEMY_DATABASE_URI="mysql://root:123456@127.0.0.1:3306/news"
    SQLALCHEMY_TRACK_MODIFICATIONS=False
    SECRET_KEY ="ASDFGHJKL"

    REDIS_HOST = "127.0.0.1"
    REDIS_PORT = 6379

    SESSION_TYPE = 'redis'
    SESSION_REDIS =StrictRedis(host=REDIS_HOST,port=REDIS_PORT)
    SESSION_USE_SIGNER =True
    PERMANENT_SESSION_LIFETIME =60*60*24

#开发环境
class DevlopmentConfig(Config):
    LEVEL_LOG = logging.DEBUG
    pass

#生产环境
class ProductionConfig(Config):
    DEBUG = False
    LEVEL_LOG =logging.WARNING
#测试环境
class UnittestConfig(Config):
    pass


configs = {
    "dev":DevlopmentConfig,
    "pro":ProductionConfig,
    "unit":UnittestConfig
}