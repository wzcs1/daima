import re
res =re.findall("^1[3456789]\d{9}$","19115542024")
print(res)