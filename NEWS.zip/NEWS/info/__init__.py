import logging
from logging.handlers import RotatingFileHandler

from flask_sqlalchemy import SQLAlchemy
from redis import  StrictRedis
from flask_wtf import  CSRFProtect
from flask_session import Session
from flask import Flask,render_template,current_app,g
from flask_wtf.csrf import generate_csrf
from config import configs

def setup_log(level):
    # 设置日志的记录等级
    logging.basicConfig(level=level) # 调试debug级
    # 创建日志记录器，指明日志保存的路径（前面的logs为文件的名字，需要我们手动创建，后面则会自动创建）、每个日志文件的最大大小、保存的日志文件个数上限。
    file_log_handler = RotatingFileHandler("./logs/log", maxBytes=1024*1024*100, backupCount=10)
    # 创建日志记录的格式               日志等级    输入日志信息的文件名   行数       日志信息
    formatter = logging.Formatter('%(levelname)s %(filename)s:%(lineno)d %(message)s')
    # 为刚创建的日志记录器设置日志记录格式
    file_log_handler.setFormatter(formatter)
    # 为全局的日志工具对象（flask app使用的）添加日志记录器
    logging.getLogger().addHandler(file_log_handler)


db =SQLAlchemy()
sr = None
def create_app(config):
    setup_log(configs[config].LEVEL_LOG)
    app = Flask(__name__)

    #配置信息的加载
    app.config.from_object(configs[config])

    #实例化SQLALchemy
    db.init_app(app)

    #实例化redis连接对象
    global  sr
    sr=StrictRedis(host=configs[config].REDIS_HOST ,port=configs[config].REDIS_PORT,decode_responses=True)

    #开启CSRP（跨站请求伪装）保护
    CSRFProtect(app)

    #实例化Session配置
    Session(app)
    from info.modules.indx import index_blue
    app.register_blueprint(index_blue)

    from info.modules.passport import passport_blue
    app.register_blueprint(passport_blue)

    from info.utils.comment import do_rank
    app.add_template_filter(do_rank,"rank")

    from info.modules.news import news_blue
    app.register_blueprint(news_blue)

    from info.modules.user import user_blue
    app.register_blueprint(user_blue)

    from info.modules.admin import admin_blue
    app.register_blueprint(admin_blue)


    @app.after_request
    def set_csrf(response):
        """
        设置csrftoken的值
        :return: 
        """
        csrf_token = generate_csrf()
        response.set_cookie("csrf_token", csrf_token)
        return response

    from info.utils.comment import get_user
    @app.errorhandler(404)
    @get_user
    def error_404(e):
        user = g.user
        current_app.logger.error(e)
        context = {
                "user":user.to_dict() if user else None
        }
        return   render_template("news/404.html",context =context)


    return app
