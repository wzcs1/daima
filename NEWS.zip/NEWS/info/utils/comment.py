from flask import session, current_app, abort,g

from info.models import User
from functools import wraps

def do_rank(num):
    if num ==1:
        return "first"
    elif num ==2:
        return "second"
    elif num ==3:
        return "third"
    else:
        return ""


def get_user(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # 1.获取session信息 - -id
        user_id = session.get("id")

        # 2.根据id获取用户信息
        user = None
        try:
            user = User.query.filter_by(id=user_id).first()
        except Exception as e:
            current_app.logger.error(e)
            abort(500)
        g.user=user
        return func(*args, **kwargs)
    return wrapper