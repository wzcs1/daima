from .import admin_blue
from flask import render_template,request,current_app,session,redirect,url_for,g,abort,jsonify
from info.models import User,News
from info.utils.comment import get_user
import time
import datetime
from info import constants
from info.response_code import RET
from info import db
@admin_blue.route("/login",methods = ["POST","GET"])
def login():
    """
    后台登录页面
    :return: 
    """
    if request.method =="POST":
        #接受参数
        username= request.form.get("username")
        password = request.form.get("password")
        print(username, password)
        #校验参数
            #校验参数是否齐全
        if not all([username,password]):
            return render_template("admin/login.html",msg="缺失参数")
            #校验用户是否存在
        try:
             user= User.query.filter_by(nick_name=username).first()
        except Exception as e:
            current_app.logger.error(e)
            return render_template("admin/login.html", msg="用户查询失败")
        if not user:
            return render_template("admin/login.html", msg="用户名或密码错误")
            #校验密码是否正确
        if not user.check_passwoid(password):
            return render_template("admin/login.html", msg="用户名或密码错误")

    #实现状态保持
        session["id"] = user.id
        session["nick_name"] = user.nick_name
        session["mobile"] = user.mobile
        session["is_admin"] = 1
    #跳转到首页
        return  redirect(url_for("admin.index"))

    id = session.get('id')
    is_admin = session.get('is_admin')
    if id and is_admin:
        return redirect(url_for("admin.index"))

    return render_template("admin/login.html")

@admin_blue.route('/index', methods=['GET', 'POST'])
@get_user
def index():
    """
    管理首页
    :return: 
    """
    user = g.user
    if not (user and user.is_admin):
       return redirect(url_for("admin.login"))
    context = {
        "user":user.to_dict()
    }

    return render_template("admin/index.html",context=context)

@admin_blue.route("/user_count")
@get_user
def user_count():

    """
    用户统计
    :return: 
    """
    #校验用户登录状态
    user = g.user
    if not (user and user.is_admin):
        return redirect(url_for("admin.login"))

    today_time = time.localtime()
    str_mon_time = "%d-%02d-01" % (today_time.tm_year,today_time.tm_mon)
    datetime_mon_time = datetime.datetime.strptime(str_mon_time,"%Y-%m-%d")
    str_today_time = "%d-%02d-%d" % (today_time.tm_year,today_time.tm_mon,today_time.tm_mday)
    datetime_today_time = datetime.datetime.strptime(str_today_time, "%Y-%m-%d")
    total_count =0
    mon_count = 0
    day_count =0
    try:
        total_count = User.query.filter_by(is_admin=False).count()#总人数
        mon_count = User.query.filter(User.is_admin==False,User.create_time>datetime_mon_time).count()#月新增
        day_count = User.query.filter(User.is_admin==False,User.create_time>datetime_today_time).count()
    except Exception as e:
        current_app.logger.error(e)
        abort(404)

    x_data = []
    y_data = []
    str_time = "%d-%02d-%d" % (today_time.tm_year,today_time.tm_mon,today_time.tm_mday)#当前时间
    date_time = datetime.datetime.strptime(str_time,"%Y-%m-%d")
    for i in range(0,15):
        start_time = date_time -datetime.timedelta(days=i+1)
        end_time = date_time - datetime.timedelta(days=1)
        res=0
        try:
            res = User.query.filter(User.is_admin==False,
                              User.create_time>start_time,
                              User.create_time<end_time ).count()
        except Exception as e:
            current_app.logger.error(e)
            abort(404)

        x_data.append(datetime.datetime.strftime(end_time,"%Y-%m-%d"))
        y_data.append(res)
    x_data.reverse()
    y_data.reverse()
    context = {
        "total_count":  total_count,                    #总人数
        "mon_count":    mon_count,                    #月增
        "day_count" :    day_count ,                  #日增
        "x_data":    x_data,                                  #天数
        "y_data":      y_data                                #月活数量
    }

    return render_template("admin/user_count.html",context=context)


@admin_blue.route("/user_list")
@get_user
def user_list():
    user = g.user
    if not (user and user.is_admin):
        return redirect(url_for("admin.login"))
    p = request.args.get("p",1)

    try:
        p = int(p)
    except Exception as e:
        current_app.logger.error(e)
        p = 1
    users= []
    current_page =0
    total_page = 0
    try:
        paginate=User.query.filter_by(is_admin=False).paginate(page=p,per_page=constants.ADMIN_USER_PAGE_MAX_COUNT)
        users = paginate.items
        current_page = paginate.page
        total_page = paginate.pages
    except Exception as e:
        current_app.logger.error(e)
        abort(500)

    context = {
        "users":users, #除了超级管理员所以用户
        "current_page":current_page, #当前页
        "total_page":total_page #总页数
    }

    return render_template("admin/user_list.html",context=context)

@admin_blue.route("/user_review")
@get_user
def user_review():
    user = g.user
    if not (user and user.is_admin):
        return redirect(url_for("admin.login"))
    p = request.args.get("p", 1)
    keyword = request.args.get("keyword")
    try:
        p = int(p)
    except Exception as e:
        current_app.logger.error(e)
        p = 1
    news = []
    current_page =1
    total_page = 1
    try:
        if keyword:
            paginate = News.query.filter(News.status != 0,News.title.contains(keyword)).paginate(page=p, per_page=constants.ADMIN_NEWS_PAGE_MAX_COUNT)
        else:
            paginate = News.query.filter(News.status != 0).paginate(page=p, per_page=constants.ADMIN_NEWS_PAGE_MAX_COUNT)
        news = paginate.items
        current_page = paginate.page
        total_page = paginate.pages
    except Exception as e:
        current_app.logger.error(e)
        abort(500)

    context ={
        "news_list":news,   #要审核的新闻
        "current_page":current_page,
        "total_page":total_page
    }
    return render_template("admin/news_review.html",context=context)

@admin_blue.route("/user_review_datail")
@get_user
def user_review_datail():
    user = g.user
    if not (user and user.is_admin):
        return redirect(url_for("admin.login"))

    news_id = request.args.get("news_id")

    if not news_id:
        abort(404)
    news = None
    try:
        news = News.query.filter_by(id=news_id).first()
    except  Exception as e:
        current_app.logger.error(e)
        abort(500)
    if not news:
        abort(404)

    context={
        "news":news
    }
    return render_template("admin/news_review_detail.html",context=context)

@admin_blue.route("/news_review_action",methods =["POST"])
@get_user
def news_review_action():

    """
    新闻审核
    1.校验用户信息
    2.接收参数
    3.校验参数
        3.1 校验参数是否齐全
        3.2 校验action是否合法
        3.3 校验当拒绝通过时 reason是否为空
        3.4 校验新闻是否存在
    4.校验不同的aciton的值完成不同的逻辑处理
    5.返回结果
    
    
    :return: 
    """
    # 校验用户信息
    user = g.user
    if not (user and user.is_admin):
        return redirect(url_for("admin.login"))

    # 接收参数
    action = request.json.get("action")
    news_id = request.json.get("news_id")
    reason = request.json.get("reason")

    # 3.校验参数
    #     3.1校验参数是否齐全
    if not all([news_id,action]):
        return jsonify(errno = RET.PARAMERR,errmsg="缺失参数")
    #     3.2校验action是否合法
    if action not in(["accept","reject"]):
        return jsonify(errno = RET.PARAMERR,errmsg="参数错误")
    #     3.3校验当拒绝通过时reason是否为空
    if action =="reject":
        if not reason:
            return jsonify(errno=RET.PARAMERR, errmsg="参数错误")
    #     3.4校验新闻是否存在
    try:
        news= News.query.filter_by(id = news_id).first()
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR, errmsg="新闻获取失败")

    if not news:
        return jsonify(errno = RET.NODATA,errmsg="未找到该新闻")
    # 4.校验不同的aciton的值完成不同的逻辑处理
    if action =="accept":
        news.status = 0
        news.reason = ""
    else:
        news.status = -1
        news.reason = reason
    try:
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()
        return jsonify(errno=RET.DBERR,errmsg ="操作失败")
        # 5.返回结果

    return jsonify(errno = RET.OK,errmsg="操作成功")

@admin_blue.route("/news_edit")
@get_user
def news_edit():
    user = g.user
    if not (user and user.is_admin):
        return redirect(url_for("admin.login"))
    p = request.args.get("p", 1)
    keyword = request.args.get("keyword")
    try:
        page = int(p)
    except Exception as e:
        current_app.logger.error(e)
        page = 1
    users = []
    current_page = 1
    total_page = 1

    # 查询数据
    try:
        # paginate = User.query.filter(User.is_admin == False).paginate(page,constants.ADMIN_USER_PAGE_MAX_COUNT,False)
        if keyword:
            paginate = News.query.filter(News.status == 0, News.title.contains(keyword)).order_by(
                News.create_time.desc()).paginate(
                page=page,
                per_page=constants.ADMIN_NEWS_PAGE_MAX_COUNT)
        else:
            paginate = News.query.filter(News.status == 0).order_by(News.create_time.desc()).paginate(page=page,
                                                                                                      per_page=constants.ADMIN_NEWS_PAGE_MAX_COUNT)
        users = paginate.items
        current_page = paginate.page
        total_page = paginate.pages
    except Exception as e:
        current_app.logger.error(e)

    context = {
        "news_list": users,
        "total_page": total_page,
        "current_page": current_page,
    }
    return render_template("admin/news_edit.html", context=context)

@admin_blue.route("/news_review_action",methods =["GET","POST"])
@get_user
def news_edit_detail():
    user = g.user
    if not (user and user.is_admin):
        return redirect(url_for('admin_blue.login'))
    news_id = request.args.get("news_id")
    if not news_id:
        abort(404)
    news = None
    try:
        news = News.query.filter_by(id=news_id).first()
    except Exception as e:
        current_app.logger.error(e)
        abort(500)
    if not news:
        abort(404)
    return render_template("admin/news_edit_detail.html")