from .import user_blue
from info.models import Category,News
from info.utils.comment import get_user
from flask import g, redirect, url_for, render_template, request, jsonify, current_app, session,abort
from info.response_code import RET
from info import db

from info import  constants
from info.utils.file_stroage import upload_file
@user_blue.route("/info")
@get_user
def user_info():
    """
    个人中心
    :return: 
    """
    user = g.user
    if not user:
        return redirect(url_for("index.index"))

    context = {
        "user":user.to_dict() if user else None
    }

    return  render_template("news/user.html",context=context)

@user_blue.route("/base_info",methods=["GET","POST"])
@get_user
def base_info():
    """
    用户基本信息功能
    :return: 
    """

    user = g.user
    if not user:
        return redirect(url_for("index.index"))

    if request.method =="POST":
        #接受参数
        signature = request.json.get("signature")
        nick_name = request.json.get("nick_name")
        gender = request.json.get("gender")
        #校验参数
            #校验用户名称是否合法
            # 校验用户标签是否合法
        if len(nick_name)>32 and len(signature)>512:
            return jsonify(errno=RET.PARAMERR,errmsg="参数错误")
            #校验性别是否合法
        if gender not in ["MAN","WOMAN"]:
            return jsonify(errno=RET.PARAMERR, errmsg="参数错误")
        # 更新数据库中用户信息
        user.nick_name = nick_name
        user.signature = signature
        user.gender = gender

        try:
            db.session.commit()
        except Exception as e:
            current_app.logger.error(e)
            db.session.rollback()
            return jsonify(errno=RET.DBERR, errmsg="信息跟新失败")

        #更新session用户信息
        try:
            session["nick_name"] = nick_name
        except Exception as e:
            current_app.logger.error(e)
            return jsonify(errno=RET.DBERR, errmsg="信息跟新失败")
        #返回结果
        return jsonify(errno=RET.OK, errmsg="成功")

    context = {
        "user": user.to_dict()
    }
    return render_template("news/user_base_info.html",context=context)

@user_blue.route("/pic_info",methods=["GET","POST"])
@get_user
def pic_info():
    """
    用户头像
    :return: 
    """
    user = g.user
    if not user:
        return redirect(url_for("index.index"))

    if request.method == "POST":
        #接收参数
        avatar_img = request.files.get("avatar")
        #校验参数
        if not avatar_img:
            return jsonify(errno=RET.PARAMERR,errmsg="参数错误")

        try:
            avatar_key = upload_file(avatar_img.read())
        except Exception as e:
            current_app.logger.error(e)
            return jsonify(errno=RET.THIRDERR,errmsg="第三方保存失败")
        if not avatar_key:
            return jsonify(errno=RET.THIRDERR,errmsg="第三方保存失败")

        user.avatar_url = avatar_key

        try:
            db.session.commit()
        except Exception as e:
            current_app.logger.error(e)
            db.session.rollback()
            return jsonify(errno =RET.DBERR,errmsg="数据保持失败")

        data = {
            "avatar_url":constants.QINIU_DOMIN_PREFIX+avatar_key
        }
        #返回数据
        return jsonify(errno=RET.OK, errmsg="成功",data=data)

    context = {
        "user":user.to_dict()
    }
    return render_template("news/user_pic_info.html",context=context)

@user_blue.route("/follow_info",methods=["GET","POST"])
@get_user
def follow_info():
    """
    用户关注
    :return: 
    """
    #1.校验用户
    user = g.user
    if not user:
        return redirect(url_for("index.index"))

    p = request.args.get("p", 1)
    try:
        p = int(p)
    except Exception as e:
        current_app.logger.error(e)
        p = 1

    follows = []
    current_page = 1
    total_page = 1
    try:
        paginate = user.followed.paginate(p, constants.USER_FOLLOWED_MAX_COUNT, False)
        # 获取当前页数据
        follows = paginate.items
        # 获取当前页
        current_page = paginate.page
        # 获取总页数
        total_page = paginate.pages
    except Exception as e:
        current_app.logger.error(e)
    user_dict_li = []
    for follow_user in follows:
        user_dict_li.append(follow_user.to_dict())
    context = {"users": user_dict_li,
            "total_page": total_page,
            "current_page": current_page,
            "user": user.to_dict() if user else None
    }
    return render_template("news/user_follow.html",context=context)


@user_blue.route("/pass_info",methods=["GET","POST"])
@get_user
def pass_info():
    """
    用户修改密码
    :return: 
    """
    user = g.user
    if not user:
        return redirect(url_for("index.index"))
    if request.method == "POST":
        #接受参数
        old_password = request.json.get("old_password")
        new_password = request.json.get("new_password")
        new_password2 = request.json.get("new_password2")
        #校验参数
            #2.1 检验参数是否完整
        if not all([old_password,new_password,new_password2]):
            return jsonify(errno=RET.PARAMERR, errmsg="参数错误")
            #2.2 校验旧密码是否正确
        if not user.check_passwoid(old_password):
            return jsonify(errno=RET.PWDERR, errmsg="密码错误")
            #2.3 校验新密码是否一致
        if new_password != new_password2:
            return jsonify(errno=RET.PARAMERR, errmsg="密码不一致")
        #修改密码
        user.password = new_password
        try:
            db.session.commit()
        except Exception as e:
            current_app.logger.error(e)
            db.session.rollback()
            return jsonify(errno=RET.DBERR, errmsg="密码修改失败")
        #返回结果
        return jsonify(errno=RET.OK, errmsg="成功")
    return render_template("news/user_pass_info.html")

@user_blue.route("/collection_info")
@get_user
def collection_info():
    """
    我的收藏
    :return: 
    """
    user = g.user
    if not user:
        return redirect(url_for("index.index"))

    #接收参数
    p = request.args.get("p",1)
    #校验参数
        #校验参数是否是数值型
    try:
        p = int(p)
    except Exception as e:
        current_app.logger.error(e)
        p = 1
    #查询该用户收藏所以新闻

    totalPage=1
    currentPage=1
    newsList =[]
    try:
        paginate = user.collection_news.paginate(page=p ,per_page=constants.USER_COLLECTION_MAX_NEWS)
        totalPage = paginate.pages #获取总页数
        currentPage = paginate.page    #获取当前页
        newsList = paginate.items   #获取对应页数数据
    except Exception as e :
        current_app.logger.error(e)
        abort(500)

    context = {
        "news_list" :newsList, #用户收藏所以新闻
        "current_page" :currentPage, #当前页
        "total_page" :totalPage #总页数
    }

    return render_template("news/user_collection.html",context = context)

@user_blue.route("/news_release",methods=["GET","POST"])
@get_user
def news_release():
    """
    新闻发布处理
    :return: 
    """
    user = g.user
    if not user:
        return redirect(url_for("index.index"))

    if request.method == "POST":
        #接收参数
        title  = request.form.get("title")  #新闻标题
        category_id = request.form.get("category_id")#新闻分类
        digest = request.form.get("digest")#新闻摘要
        index_image = request.files.get("index_image")#图片
        content = request.form.get("content")#新闻内容
        #校验参数
            #校验参数是否齐全
        if not all([title,category_id,digest,index_image,content]):
            return jsonify(errno=RET.PARAMERR, errmsg="参数错误")
            #校验新闻标题长度是否合法
            # 校验摘要长度是否合法
        if len(title) >256 or len(digest) >512 :
            return jsonify(errno=RET.PARAMERR, errmsg="参数错误")
            # #查询新闻分类是否存在
        try:
            category = Category.query.filter_by(id = category_id).first()
        except Exception as e:
            current_app.logger.error(e)
            return jsonify(errno=RET.DBERR, errmsg="分类查询失败")
        if not category:
            return jsonify(errno=RET.NODATA, errmsg="未找到该分类")

        #校验图片
        try:
            key = upload_file(index_image.read())
        except Exception as e:
            current_app.logger.error(e)
            return jsonify(errno = RET.THIRDERR,errmsg="图片保持失败")
        if not key:
            return jsonify(errno=RET.THIRDERR, errmsg="图片保持失败")

        #创建新闻对象
        new_news = News()
        new_news.title =title
        new_news.source = "个人发布"
        new_news.digest =digest
        new_news.content = content
        new_news.index_image_url =constants.QINIU_DOMIN_PREFIX + key
        new_news.category_id = category_id
        new_news.user_id = user.id
        new_news.status = 0

        db.session.add(new_news)

        try:
            db.session.commit()
        except Exception as e:
            current_app.logger.error(e)
            db.session.rollback()
            return jsonify(errno=RET.DBERR,errmsg="新闻发表失败")
        #返回数据
        return jsonify(errno=RET.OK, errmsg="成功")

    try:
        categories = Category.query.all()[1:]
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno = RET.DBERR,errmsg = "查询失败")
    context ={
        "categories": categories  #所以新闻分类
    }
    return render_template("news/user_news_release.html",context=context)

