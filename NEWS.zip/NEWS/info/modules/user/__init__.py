from  flask import  Blueprint

#实例化蓝图对象
user_blue = Blueprint("user",__name__,url_prefix="/user")

from .import views