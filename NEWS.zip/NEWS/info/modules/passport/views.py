import re
import random
from werkzeug.security import check_password_hash

from .import passport_blue
from flask import request,abort,current_app,make_response,jsonify,session
from info.utils.captcha .captcha import captcha
from info import sr

from info.response_code import RET
from info.libs.yuntongxun.sms import CCP
from info import constants
from info.models import User
from datetime import datetime
from info import db
@passport_blue.route("/image_code")
def image_code():
    """
        生成图片验证码
    1.接受参数（uuid）
    2.校验参数
        2.1 校验uuid是否携带
    3.生成图片验证
    4.将图片验证保持到redis中
    5.返回图片验证
    :return: 图片响应对象
    """
    # 1.接受参数（uuid）
    imageCodeId=request.args.get("imageCodeId")
    # 2.校验参数
    # 2.1校验uuid是否携带
    if not imageCodeId:
        abort(403)
    # 3.生成图片验证
    name,imageCodeText,imageCode=captcha.generate_captcha()
    # 4.将图片验证保持到redis中
    try:
        sr.set("imageCode:"+imageCodeId,imageCodeText,ex=constants.IMAGE_CODE_REDIS_EXPIRES)
    except Exception as e:
        current_app.logger.error(e)
        abort(500)
    # 5.返回图片验证
    response=make_response(imageCode)
    response.headers["Content-Type"] ="/image/jpg"
    print(imageCodeText)
    return response

@passport_blue.route("/sms_code",methods =["POST"])
def sms_code():
    """
        发送短信
    1.接收参数
    2.校验参数
        2.1 校验参数是否齐全
        2.2 手机号是否合法
        2.3 根据uuid从redis中获得图片的文本
        2.4 判断图形文本是否存在
        2.5 判断用户发的和数据库中的是否一致
    3.发送短信验证码
    4.用户保存验证码
    5.返回结果
    :return: 
    """


    # 1.接收参数
    mobile=request.json.get("mobile")
    image_code=request.json.get("image_code")
    image_code_id =request.json.get("image_code_id")
    # 2.校验参数
    #     2.1 校验参数是否齐全
    if not all([mobile, image_code, image_code_id]):
        return jsonify(errno=RET.PARAMERR, errmsg="缺失参数")
    #     2.2 手机号是否合法
    mobile = mobile.strip()#消除前后空格
    if not re.findall("^1[3456789]\d{9}$",mobile):
        return jsonify(errno=RET.PARAMERR, errmsg="缺失参数")
    #     2.3 根据uuid从redis中获得图片的文本
    try:
        image_code_server=sr.get("imageCode:"+image_code_id)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR, errmsg="图片验证码获取失败")
    #     2.4 判断图形文本是否存在
    if not image_code_server:
        return jsonify(errno=RET.NODATA, errmsg="图片验证码获取失败")
    #     2.5 判断用户发的和数据库中的是否一致
    if not image_code_server.lower()==image_code.lower():
        return jsonify(errno=RET.DATAERR, errmsg="图片验证码错误")
    # 3.发送短信验证码
        #3.1 随机4为验证码
    sms_number = "%04d"%random.randint(0,9999)
    print(sms_number)
    try:
        res=CCP().send_template_sms(mobile, [sms_number, constants.SMS_CODE_REDIS_EXPIRES//60], 1)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.THIRDERR, errmsg="短信发送失败")
    if res !=0:
        return jsonify(errno=RET.THIRDERR, errmsg="短信发送失败")
    try:
        sr.set("SMS:"+mobile, sms_number,ex=constants.SMS_CODE_REDIS_EXPIRES)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR, errmsg="短信保持失败")
    # 4.返回结果
    return jsonify(errno=RET.OK, errmsg="成功")

@passport_blue.route("/register",methods =["POST"])
def register():
    """"
    注册功能
    1.接受参数
    2.校验参数
        2.1校验参数是否齐全
        2.2 校验手机号是否正确
        2.3 校验手机号是否注册
        2.4 校验短信验证码是否正确
    3.实例化用户信息
    4.实现状态保持
    5.返回数据
    """
#     1.接受参数
    mobile =request.json.get("mobile")#手机号
    smscode =request.json.get("smscode")#短信验证
    password =request.json.get("password")#密码
#     2.校验参数
    #     2.1 校验参数是否齐全
    if not all([mobile,smscode,password]):
        return jsonify(errno=RET.PARAMERR, errmsg="缺失参数")
    #     2.2 校验手机号是否正确
    if not re.findall("^1[3456789]\d{9}$",mobile):
        return jsonify(errno=RET.PARAMERR, errmsg="缺失参数")
    #     2.3 校验手机号是否注册
    try:
        user=User.query.filter_by(mobile=mobile).first()
    except Exception as e :
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR, errmsg="数据查询错误")

    if user:
        return jsonify(errno=RET.DATAEXIST, errmsg="该用户已存在")
    #     2.4 校验短信验证码是否正确
    if not smscode ==sr.get("SMS:" + mobile):
        return jsonify(errno=RET.PARAMERR, errmsg="短信验证码错误")
#    3. 实例化用户信息
    new_user = User()
    new_user.nick_name =mobile
    new_user.password=password
    new_user.mobile = mobile
    new_user.create_time=datetime.now()
    db.session.add(new_user)
    try:
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback() #回滚
        return jsonify(errno=RET.DBERR, errmsg="用户保持失败")

#    4.实现状态保持
    session.pop('id', None)
    session.pop('nick_name', None)
    session.pop('mobile', None)
    session.pop('is_admin', None)

    # session["id"] = new_user.id
    # session["nick_name"] = new_user.nick_name
    # session["mobile"] = new_user.mobile
#    5.返回数据
    return jsonify(errno=RET.OK, errmsg="注册成功！")

@passport_blue.route("/login",methods =["POST"])
def login():
    """"
    1. 接收参数
    2.校验手机号
     2.1校验参数是否齐全
     2.2 校验手机号是否正确
     2.3校验手机号是否是登录用户
    3.校验密码
    #4.更新最后登录时间
    # 5.实现状态保持
    # 6.返回数据
    """
    # 1.接收参数
    mobile = request.json.get("mobile")  # 手机号
    password = request.json.get("password")  # 密码
    # 2.校验手机号
        # 2.1校验参数是否齐全
    if not all([mobile,password]):
        return jsonify(errno=RET.PARAMERR, errmsg="缺失参数")
        # 2.2校验手机号是否正确
    if not re.findall("^1[3456789]\d{9}$", mobile):
        return jsonify(errno=RET.PARAMERR, errmsg="缺失参数")
        # 2.3 校验手机号是否是登录用户
    try:
        user=User.query.filter_by(mobile=mobile).first()
    except Exception as e :
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR, errmsg="数据查询错误")
    if not user:
        return jsonify(errno=RET.USERERR, errmsg="用户名或密码错误")
    # 3.校验密码是否正确
    if not check_password_hash(user.password_hash,password):
        return jsonify(errno= RET.PWDERR,errmsg="密码错误")

    #4.更新最后登录时间
    user.create_time = datetime.now()
    # db.session.add(user)
    try:
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()  # 回滚
        return jsonify(errno=RET.LOGINERR, errmsg="用户登录失败")
    #    5.实现状态保持
    session.pop('id', None)
    session.pop('nick_name', None)
    session.pop('mobile', None)
    session.pop('is_admin', None)

    session['id'] = user.id
    session['nick_name'] = user.nick_name
    session['moblie'] = user.mobile
    # 6.返回数据
    return jsonify(errno=RET.OK, errmsg="登陆成功！")

@passport_blue.route("/logout")
def logout():
    """
    用户退出
    :return: 
    """
    try:
        session.pop("id",None)
        session.pop("nick_name",None)
        session.pop("mobile",None)
        session.pop("is_admin",None)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR, errmsg="退出失败")
    return jsonify(errno=RET.OK, errmsg="退出成功！")