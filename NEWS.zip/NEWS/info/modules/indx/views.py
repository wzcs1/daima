from .import index_blue
from info import  sr
from flask import render_template, current_app, session, abort, jsonify, request, g
from info.models import User,News,Category
from info import constants
from info.response_code import RET
from info.utils.comment import get_user
@index_blue.route('/')
@get_user
def index():
    """
        首页模块
    1.获取session信息--id
    2.根据id获取用户信息
    3.获取新闻排行相关内容
    4.新闻分类处理
    :return: 
    """

    # 1.获取session信息 - -id
    # user_id = session.get("id")
    # 2.根据id获取用户信息
    # user =None
    # try:
    #     user = User.query.filter_by(id=user_id).first()
    # except Exception as e:
    #     current_app.logger.error(e)
    #     abort(500)
    user = g.user

    #3. 获取新闻排行相关内容  desc:降序 limit:取前6条
    news_clicks =[]
    try:
        news_clicks=News.query.order_by(News.clicks.desc()).limit(6)
    except Exception as e:
        current_app.logger.error(e)
        abort(500)
    #4.新闻分类处理
    categories = []
    try:
        categories= Category.query.all()
    except Exception as e :
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR, errmsg="分类查询失败")
    #构造上下文
    context ={
        "user":user.to_dict() if user else None,
        "news_clicks":news_clicks,
        "categories":categories
    }

    return render_template("news/index.html",context=context)

@index_blue.route('/news_list')
def news_list():
    """
    新闻获取
    1.获取参数
    2.校验参数
        2.1 校验参数是否齐全 cid
        2.2 校验page和per_page是否是数值型
    3.完成新闻获取（分页）
    4.返回数据 
    :return: 
    """
    # 1.获取参数
    cid = request.args.get("cid")
    page = request.args.get("page",1)
    per_page = request.args.get("per_page",constants.HOME_PAGE_MAX_NEWS)
    # 2.校验参数
    #     2.1校验参数是否齐全cid
    if not cid:
        return jsonify(errno=RET.PARAMERR,errmsg="缺失参数")
    #     2.2 校验page和per_page是否是数值型
    try:
        cid = int(cid)
        page = int(page)
        per_page=int(per_page)
    except Exception as e :
       current_app.logger.error(e)
       cid = 1
       page = 1
       per_page = constants.HOME_PAGE_MAX_NEWS
    # 3.完成新闻获取（分页）
    try:
        if cid ==1:
            paginate = News.query.order_by(News.create_time.desc()).paginate(page=page,per_page=per_page)
        else:
            paginate = News.query.filter_by(category_id=cid).order_by(News.create_time.desc()).paginate(page=page,per_page=per_page)
    except Exception as e :
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR,errmsg="新闻获取失败")

    totalPage = paginate.pages
    currentPage = paginate.page
    newsList = paginate.items

    newsList_dict = []
    for news in newsList:
        newsList_dict.append(news.to_basic_dict())
    data = {
    "total_page" : totalPage,
    "currentPage" : currentPage,
    "news_dict_list" : newsList_dict
    }
    # 4.返回数据
    return jsonify(errno= RET.OK,errmsg="成功！",data=data)


@index_blue.route("/favicon.ico")
def set_icon():
    """设置左侧图标"""
    return current_app.send_static_file("news/favicon.ico",)