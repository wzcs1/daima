from info.models import User, News, Comment, CommentLike
from .import news_blue
from flask import render_template, session, current_app, abort,g,request,jsonify
from info import db
from info.utils.comment import get_user
from  info.response_code import RET

@news_blue.route('/detail/<int:id>')
@get_user
def detail(id):
    """
    1.获取session信息 - -id
    2.根据id获取用户信息
    3.获取新闻排行相关内容  desc:降序 limit:取前6条
    4.获取内容--》id
    5.点击量
    6.收藏按钮展示
    7.获取所以的评论
    :param id: 
    :return: 
    """
    # 1.获取session信息 - -id
    # user_id = session.get("id")
    # 2.根据id获取用户信息
    # user = None
    # try:
    #     user = User.query.filter_by(id=user_id).first()
    # except Exception as e:
    #     current_app.logger.error(e)
    #     abort(500)
    user = g.user

    # 3. 获取新闻排行相关内容  desc:降序 limit:取前6条
    news_clicks = []
    try:
        news_clicks = News.query.order_by(News.clicks.desc()).limit(6)
    except Exception as e:
        current_app.logger.error(e)
        abort(500)
    #4.获取内容--》id
    news =None
    try:
        news = News.query.filter_by(id=id).first()
    except Exception as e:
        current_app.logger.error(e)
        abort(500)

    # 5.点击量
    if  news:
        try:
            news.clicks += 1
            db.session.commit()
        except Exception as e:
            current_app.logger.error(e)
            db.session.rollback()
            abort(500)

    if not news:
        abort(404)

    #6.收藏按钮展示
    is_collected=False
    if user:
        if  news  in user.collection_news:
            is_collected=True

    # 7.获取所以的评论
    comment_list = []
    try:
        comment_list = Comment.query.filter_by(news_id=news.id).order_by(Comment.create_time.desc()).all()
    except Exception as e:
        current_app.logger.error(e)
        abort(500)

    commentLike_ids = []

    if user:
        try:
            commentLike_ids = [i.comment_id for i in  CommentLike.query.filter_by(user_id=user.id).all()]
        except Exception as e:
            current_app.logger.error(e)
            abort(500)

    comments = []
    for comment in comment_list:
        new_dict_comment = comment.to_dict()

        new_dict_comment["is_like"] =False
        if  comment.id in commentLike_ids:
            new_dict_comment["is_like"] = True

        comments.append(new_dict_comment)

    #构造上下文
    context = {
        "user": user,
        "news_clicks": news_clicks,
        "news":news,
        "is_collected":is_collected,
        "comments":comments
    }
    if user:
        context["user"] = user.to_dict()
    return render_template("news/detail.html",context=context)


@news_blue.route('/news_collect',methods=["POST"])
@get_user
def news_collect():
    """
    收藏功能
    1.校验用户
    2.接受参数
    3.校验参数
        3.1 校验参数是否齐全
        3.2 校验action是否合法
        3.3 校验新闻是否存在
    4.收藏处理
    5.返回结果
    :return: 
    """
    #1.校验用户是否登录
    user = g.user
    if not user:
        return jsonify(errno=RET.SESSIONERR,errmsg="用户未登录")
    # 2.接收参数
    news_id = request.json.get("news_id")
    action = request.json.get("action")
    # 3.校验参数
    #   3.1校验
    if not all([news_id,action]):
        return jsonify(errno=RET.PARAMERR,errmsg="缺失参数")
    #   3.2校验action是否齐全
    if action not in ["collect","cancel_collect"]:
        return jsonify(errno=RET.PARAMERR,errmsg="非法参数")
    #   3.3 校验新闻是否存在
    try:
        news = News.query.filter_by(id = news_id).first()
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno = RET.DBERR,errmsg="数据库查询失败")
    if not news:
        return jsonify(errno = RET.NODATA,errmsg="未找到该新闻")
    #4.收藏处理
    if action =="collect":
        if news not in user.collection_news:
            user.collection_news.append(news)
    else:
        if news in user.collection_news:
            user.collection_news.remove(news)
    try:
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()
        return jsonify(errno=RET.DBERR, errmsg="收藏失败！")
    # 5.返回结果
    return jsonify(errno=RET.OK, errmsg="收藏成功！")

@news_blue.route('/news_comment',methods=["POST"])
@get_user
def news_comment():
    """
    1.校验用户是否登录
    2.接收参数
    3.校验参数
        3.1 校验参数是否齐全
        3.2 校验数据类型是否合法
        3.3 校验新闻是否存在
    4. 创建评论信息
    5.返回结果
    :return:
    """
    # 1.校验用户是否登录
    user = g.user
    if not user:
        return jsonify(errno=RET.SESSIONERR, errmsg="用户未登录")
    # 2.接收参数
    news_id = request.json.get("news_id")
    comment = request.json.get("comment")
    parent_id = request.json.get("parent_id")
    # 3.校验参数
    #   3.1校验
    if not all([news_id, comment]):
        return jsonify(errno=RET.PARAMERR, errmsg="缺失参数")
    # 3.2校验数据类型是否合法
    try:
        news_id = int(news_id)
        if parent_id:
            parent_id =int(parent_id)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.PARAMERR, errmsg="参数错误")
    # 3.3 校验新闻是否存在
    try:
        news = News.query.filter_by(id=news_id).first()
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR, errmsg="数据库查询失败")
    if not news:
        return jsonify(errno=RET.NODATA, errmsg="未找到该新闻")

    #4.创建评论信息
    new_comment =Comment()

    new_comment.user_id = user.id
    new_comment.news_id = news.id
    new_comment.content = comment
    if parent_id:
        new_comment.parent_id = parent_id
    db.session.add(new_comment)
    try:
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()
        return jsonify(errno=RET.DBERR, errmsg="评论保持失败")
    #5.返回结果
    return jsonify(errno=RET.OK, errmsg="评论成功",data=new_comment.to_dict())

@news_blue.route('/comment_like',methods=["POST"])
@get_user
def comment_like():
    """
    1.校验用户
    2.接收参数
    3.校验参数
        3.1 校验参数是否齐全
        3.2 校验评论id和新闻id是否合法
        3.3 校验action
        3.4评论是否存在
        3.5 校验新闻是否存在
    4.根据不同的action传值完成不同处理
    5.返回结果
    :return: 
    """
    # 1.校验用户是否登录
    user = g.user
    if not user:
        return jsonify(errno=RET.SESSIONERR, errmsg="用户未登录")
    # 2.接收参数
    comment_id = request.json.get("comment_id")
    action = request.json.get("action")
    news_id = request.json.get("news_id")
    # 3.校验参数
    #   3.1校验
    if not all([comment_id, action,news_id]):
        return jsonify(errno=RET.PARAMERR, errmsg="缺失参数")
    # 3.2校验数据类型是否合法
    try:
        comment_id = int(comment_id)
        news_id = int(news_id)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.PARAMERR, errmsg="参数错误")

    #3.3 校验action
    if action not in["add","remove"]:
        return jsonify(errno=RET.PARAMERR,errmsg="非法参数")
    # 3.4 校验新闻评论是否存在
    try:
        comment = Comment.query.filter_by(id=comment_id).first()
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR, errmsg="数据库查询失败")
    if not comment:
        return jsonify(errno=RET.NODATA, errmsg="未找到该新闻")

    #3.5 校验新闻是否存在
    try:
        news = News.query.filter_by(id=news_id).first()
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR, errmsg="数据库查询失败")
    if not news:
        return jsonify(errno=RET.NODATA, errmsg="未找到该新闻")

    # 4.根据不同的action传值完成不同处理
    try:
        commentLike = CommentLike.query.filter_by(comment_id=comment_id,user_id=user.id).first()
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=RET.DBERR, errmsg="数据库查询失败")


    if action =="add":
        if  not commentLike:
            new_commentLike = CommentLike()
            new_commentLike.comment_id = comment.id
            new_commentLike.user_id = user.id
            db.session.add(new_commentLike)

            comment.like_count += 1
    else:
        if commentLike:
            db.session.delete(commentLike)
            comment.like_count -= 1

    try:
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()
        return jsonify(errno=RET.DBERR, errmsg="数据库查询失败")

    return jsonify(errno=RET.OK, errmsg="成功")

