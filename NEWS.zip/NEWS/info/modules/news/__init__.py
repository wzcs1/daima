from  flask import  Blueprint

#实例化蓝图对象
news_blue = Blueprint("news",__name__,url_prefix="/news")

from .import views