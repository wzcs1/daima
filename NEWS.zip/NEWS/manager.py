from flask import Flask
from flask_script import  Manager
from flask_migrate import  Migrate,MigrateCommand
from info import db
from  info import  create_app
from  info import models

import re
app =create_app("dev")

#集成脚本
manager = Manager(app)
Migrate(app,db)
manager.add_command("mysql",MigrateCommand)

@manager.option('-u', '--username', dest='username')
@manager.option('-p', '--password', dest='password')
@manager.option('-m', '--mobile', dest='mobile')
def createuser(username,password,mobile):
    #校验参数
        #校验参数是否齐全
    if not all([username,password,mobile]):
        print("缺失关键参数")
        return
        #校验用户名是否合法
    if len(username)>32:
        print("用户名过长")
        return
        #校验手机号是否合法
    if not re.findall("^1[3456789]\d{9}$", mobile):
       print("手机号不合法")
       return
    #创建用户
    new_user = models.User()
    new_user.nick_name =username
    new_user.password =password
    new_user.mobile = mobile
    new_user.is_admin = True
    db.session.add(new_user)
    try:
       db.session.commit()
    except Exception as e:
        print(e)
        return
    #返回值
    print("创建成功")


if __name__ == '__main__':
    manager.run()
