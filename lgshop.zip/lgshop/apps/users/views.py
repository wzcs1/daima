from django.shortcuts import render, redirect, reverse
from django.views import View
from django import http
from django_redis import get_redis_connection

from .forms import RegisterForm,LoginForm
from .models import User
from django.contrib.auth import login,authenticate,logout
from utills.response_code import RETCODE
from django.contrib.auth.mixins import LoginRequiredMixin

class UserInfoView(LoginRequiredMixin,View):
    """ 用户个人中心"""
    def get(self,request):
        """个人中心页面"""
        # if request.user.is_authenticated:
        #     #已登录
        #     return render(request,'user_center_info.html')
        # else:
        #     return redirect(reverse('users:login'))
        # login_url = '/users/login/'

        return render(request, 'user_center_info.html')

class LogouView(View):
    """用户退出登录"""
    def get(self,request):
        #实现用户退出
        #清除状态保存
        logout(request)

        #重定向
        response = redirect(reverse('contents:index'))
        #删除cookic信息
        response.delete_cookie('username')

        return response

class LoginView(View):
    '''用户登录'''
    def get(self,requset):
        """
        提供登录页面
        """
        return render(requset,'login.html')

    def post(self,request):
        """
        实现登录逻辑
        """
        login_form = LoginForm(request.POST)
        if login_form.is_valid():
            # 从表单中获取数据进行校验
            username = login_form.cleaned_data.get('username')
            password = login_form.cleaned_data.get('password')
            remembered = login_form.cleaned_data.get('remembered')
            if not all([username,password]):
                return http.HttpResponseForbidden('缺失参数')
            #校验用户名密码是否注册
            user =  authenticate(username=username,password=password)
            if user is None:
                return render(request,'login.html',{'account_errmsg':'账号或密码错误'})
            #实现状态保持
            login(request,user)

            if remembered != True:
                #没有记住登录，浏览器关闭是就销毁状态保持
                request.session.set_expiry(0)
            else:
               #记住登录 状态保存默认2周
               request.session.set_expiry(None)


            next = request.GET.get('next')
            if next:
                response = redirect(next)
            else:
                #为了实现在首页显示用户名，需要将用户实在到cookie中
                response = redirect(reverse('contents:index'))

            response.set_cookie('username',user.username,max_age=3600*24)
            #响应结果，重定向到首页
            return response
        else:
            context = {
                'forms_errors': login_form.errors
            }
            return render(request, 'login.html', context=context)



class RegisterView(View):

    def get(self, request):
        """提供用户注册页面"""
        return render(request, 'register.html')
    def post(self,request):
        """
        用户注册
        :param request:
        :return:
        """
        #校验参数
        register_form = RegisterForm(request.POST)
        if register_form.is_valid():
            #从表单中获取数据进行校验
            username = register_form.cleaned_data.get('username')
            password = register_form.cleaned_data.get('password')
            mobile = register_form.cleaned_data.get('mobile')


            #短信验证码
            sms_code_client = register_form.cleaned_data.get('sms_code')
            #校验短信验证码
            redis_conn = get_redis_connection('verify_code')
            sms_code_server = redis_conn.get('sms_%s' % mobile)

            if sms_code_server.decode() is None:
                return render(request,'register.html',{'sms_code_errmsg':'短信验证码失效'})
            if sms_code_server.decode() !=sms_code_client:
                return render(request,'register.html',{'sms_code_errmsg':'输入短信验证码有误'})

            #把表单数据保存到数据库中
            try:
                user = User.objects.create_user(username=username,password=password,mobile=mobile)
            except Exception as e:
                return render(request,'register.html',{'register_errmsg':'注册失败'})

            #状态保持
            #使用django内置的login实现的用户状态保持（from django.contrib.auth import login）
            login(request,user)
            #响应结果
            return redirect(reverse('contents:index'))#重定向到首页
        else:
            context = {
                'forms_errors': register_form.errors
            }
            return render(request,'register.html',context=context)

class UsernameCountView(View):
    """判断用户名是否被注册"""
    def get(self,request,username):
        """
        :param username:用户名
        :return:返回用户名是否重复 JSON数据
        """
        count = User.objects.filter(username=username).count()

        return http.JsonResponse({'code':200,'errmsg':'OK','count':count})

class MobileView(View):
    """判断手机号是否被注册"""
    def get(self,request,mobile):
        count = User.objects.filter(mobile=mobile).count()
        return http.JsonResponse({'code':RETCODE.OK,'errmsg':'OK','count':count})