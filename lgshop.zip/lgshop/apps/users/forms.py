from django import forms

class RegisterForm(forms.Form):
    username = forms.CharField(max_length=20,min_length=5,required=True,#用户名
error_messages={"max_length":'用户名最长为20','min_length':'用户名最少为5'})
    password = forms.CharField(max_length=20,min_length=5,required=True,#密码
error_messages={"max_length": '用户密码最长为12', 'min_length': '用户密码最短为7'})
    password2 = forms.CharField(max_length=12, min_length=7, required=True)#确认密码
    mobile = forms.CharField(max_length=11,min_length=11,required=True,#手机号
error_messages={"max_length":'手机号最长为11','min_length':'手机号最短为11'})
    sms_code = forms.CharField(max_length=6,min_length=6,required=True)#验证码

    def clean(self):
        clenedd_data = super().clean()
        password = clenedd_data.get('password')
        password2 = clenedd_data.get('password2')

        if password != password2:
            raise forms.ValidationError('两次密码不一致')#抛异常
        return clenedd_data

class LoginForm(forms.Form):
    username = forms.CharField(max_length=20,min_length=5,error_messages={"max_length":'用户名最长为20','min_length':'用户名最少为5'})
    password = forms.CharField(max_length=20,min_length=5,error_messages={"max_length":'用户密码最长为20','min_length':'用户密码最少为5'})
    remembered = forms.BooleanField(required=False)