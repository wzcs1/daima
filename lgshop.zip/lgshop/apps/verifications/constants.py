
#图形验证码有效期间 单位：秒
IMAGE_CODE_REDIS_EXPIRES = 300

#短信验证码有效期间 单为：秒
SMS_CODE_REDIS_EXPIPES = 300

#短信模板
SEND_SMS_TEMPLATE_ID = 1


#60S内是否重复发送标记
SEND_SMS_COOE_TIMES = 60