import logging

from django.contrib.auth import login
from django.shortcuts import render, redirect
from django.views import  View
from QQLoginTool.QQtool import OAuthQQ
from django import http
from django.conf import settings
from utills.response_code import RETCODE
import logging
from .models import OAuthQQUser
from .utils import generate_access_token
#创建一个日志输出器
logger = logging.getLogger('django')

class QQAuthUserView(View):
    def get(self,request):
        """qq登录回调·处理"""
        code = request.GET.get('code')
        if not code:
            return http.HttpResponseForbidden('获取code失败')
            # 创建工具对象
        oauth = OAuthQQ(client_id=settings.QQ_CLIENT_ID,
                client_secret=settings.QQ_CLIENT_SECRET,
                redirect_uri=settings.QQ_REDIRECT_URI)
        try:
            #使用code获取access_token
            access_token = oauth.get_access_token(code)
            #使用access_token获取openid
            openid = oauth.get_open_id(access_token)
        except Exception as e:
            logger.error(e)#记录日志
            return http.HttpResponseServerError('OAuth2.0认证失败')

        #openid qq用户id
        #使用openid判断QQ是否绑定商城用户
        try:
            oauth_user = OAuthQQUser.objects.get(openid=openid)
        except OAuthQQUser.DoesNotExist:
            #如果没有找到记录 openid 未绑定商城用户 展示绑定页面
            #openid 是明文，所以要加密
            context = {'access_token_openid':generate_access_token(openid)}
            return render(request, 'oauth_callback.html',context=context)
        else:
            #找到了 登录
            #状态保存
            login(request,oauth_user.user)

            next = request.GET.get('state')

            response = redirect(next)

            response.set_cookie('username',oauth_user.user.username,max_age=3600*24)

            #重定向到首页
            return response

class QQAuthURLView(View):
    '''提供QQ登录页面'''

    def get(self,request):
        next = request.GET.get('next')
        #创建工具对象
        oauth = OAuthQQ(client_id=settings.QQ_CLIENT_ID,
 client_secret=settings.QQ_CLIENT_SECRET,
                        redirect_uri=settings.QQ_REDIRECT_URI,state=next)
        #生成扫描链接地址
        login_url = oauth.get_qq_url()
        return http.JsonResponse({'code':RETCODE.OK,'errmsg':'OK','login_url':login_url})