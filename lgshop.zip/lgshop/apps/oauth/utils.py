from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from django.conf import settings
from . import constants

def generate_access_token(openid):
    serializer = Serializer(settings.SECRET_KEY,constants.ACCESS_TOKEN_EXPIRES)#SECRET_KEY密文 ACCESS_TOKEN_EXPIRES秒
    data={'openid':openid}
    token = serializer.dumps(data)#加密
    return token.decode()