# @ Time    : 2021/1/20 21:57
# @ Author  : JuRan
from django.urls import path
from . import views

urlpatterns = [
    # 提供QQ登录扫描页面
    path('qq/login/', views.QQAuthURLView.as_view()),
    path('oauth_callback/', views.QQAuthUserView.as_view()),
]