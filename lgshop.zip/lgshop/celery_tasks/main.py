from celery import Celery
#celery入口文件
#创建celery实列
celery_app = Celery('lg')

#加载配置文件
celery_app.config_from_object('celery_tasks.config')

#注册任务
celery_app.autodiscover_tasks(['celery_tasks.sms'])

#启动celery
#   celery -A celery_tasks.main worker  -l info --pool=solo